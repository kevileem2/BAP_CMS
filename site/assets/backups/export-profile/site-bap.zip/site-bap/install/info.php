<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "bap", 
	'summary' => "bap", 
	'screenshot' => ""
	);
